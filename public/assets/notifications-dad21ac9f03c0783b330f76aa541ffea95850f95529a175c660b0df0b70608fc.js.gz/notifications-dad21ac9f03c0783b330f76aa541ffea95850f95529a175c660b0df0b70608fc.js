$(document).ready(function(){
  $(".alert").fadeOut(3500);
});
