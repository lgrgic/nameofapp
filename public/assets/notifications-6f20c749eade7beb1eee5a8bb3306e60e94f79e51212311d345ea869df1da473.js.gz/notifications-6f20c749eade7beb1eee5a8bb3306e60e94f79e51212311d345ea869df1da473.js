$(document).ready(function(){
  $(".alert").fadeOut(5000);
});
