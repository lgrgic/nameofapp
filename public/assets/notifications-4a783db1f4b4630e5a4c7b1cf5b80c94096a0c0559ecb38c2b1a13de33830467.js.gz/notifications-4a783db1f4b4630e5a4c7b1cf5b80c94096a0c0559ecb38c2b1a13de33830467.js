$(document).ready(function(){
  $(".alert").fadeOut(8000);
});
